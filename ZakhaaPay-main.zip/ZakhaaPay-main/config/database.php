<?php
/**
 * ZakhaaPay Database Configuration
 * Handles all database connections and configurations
 */

// Database credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'zakhaa_pay');

// API Configuration
define('API_URL', 'http://localhost:8000');
define('API_TIMEZONE', 'Africa/Johannesburg');

// Security
define('JWT_SECRET', 'zakhaa_pay_secret_key_2026_prod');
define('HASH_ALGO', 'sha256');

// Create connection
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Check connection
    if ($conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    // Set charset to utf8
    $conn->set_charset("utf8mb4");
    
    // Set timezone
    date_default_timezone_set(API_TIMEZONE);
    
} catch (Exception $e) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection failed',
        'error' => $e->getMessage()
    ]);
    exit();
}
?>