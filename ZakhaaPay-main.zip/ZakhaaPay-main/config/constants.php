<?php
/**
 * ZakhaaPay Application Constants
 */

// HTTP Status Codes
define('HTTP_OK', 200);
define('HTTP_CREATED', 201);
define('HTTP_BAD_REQUEST', 400);
define('HTTP_UNAUTHORIZED', 401);
define('HTTP_FORBIDDEN', 403);
define('HTTP_NOT_FOUND', 404);
define('HTTP_CONFLICT', 409);
define('HTTP_INTERNAL_ERROR', 500);

// Transaction Types
define('TXN_TYPE_PAYMENT', 'payment');
define('TXN_TYPE_TRANSFER', 'transfer');
define('TXN_TYPE_VOUCHER', 'voucher');
define('TXN_TYPE_MARKETPLACE', 'marketplace');
define('TXN_TYPE_AIRTIME', 'airtime');

// Transaction Status
define('TXN_STATUS_PENDING', 'pending');
define('TXN_STATUS_SUCCESS', 'success');
define('TXN_STATUS_FAILED', 'failed');
define('TXN_STATUS_CANCELLED', 'cancelled');

// User Roles
define('ROLE_USER', 'user');
define('ROLE_SELLER', 'seller');
define('ROLE_ADMIN', 'admin');
define('ROLE_SUPER_ADMIN', 'super_admin');

// Payment Methods
define('PAYMENT_METHOD_QR', 'qr');
define('PAYMENT_METHOD_TRANSFER', 'transfer');
define('PAYMENT_METHOD_PAYSHAP', 'payshap');
define('PAYMENT_METHOD_VOUCHER', 'voucher');

// Currency
define('CURRENCY', 'ZAR');
define('CURRENCY_SYMBOL', 'R');

// Transaction Fees
define('TRANSACTION_FEE_PERCENT', 1.5);
define('MARKETPLACE_COMMISSION_PERCENT', 5.0);
define('MIN_TRANSACTION_AMOUNT', 10);
define('MAX_TRANSACTION_AMOUNT', 50000);
define('MAX_DAILY_TRANSACTION', 50000);

// Voucher Constants
define('VOUCHER_VALIDITY_DAYS', 30);
define('VOUCHER_PREFIX', 'ZKP');

// Token expiry times
define('ACCESS_TOKEN_EXPIRY', 86400);
define('REFRESH_TOKEN_EXPIRY', 604800);

// Success Messages
define('MSG_LOGIN_SUCCESS', 'Login successful');
define('MSG_REGISTER_SUCCESS', 'Registration successful');
define('MSG_TRANSACTION_SUCCESS', 'Transaction completed successfully');
define('MSG_UPDATE_SUCCESS', 'Update successful');
define('MSG_DELETE_SUCCESS', 'Deleted successfully');

// Error Messages
define('MSG_INVALID_CREDENTIALS', 'Invalid email or password');
define('MSG_USER_NOT_FOUND', 'User not found');
define('MSG_INSUFFICIENT_BALANCE', 'Insufficient balance');
define('MSG_INVALID_AMOUNT', 'Invalid transaction amount');
define('MSG_TRANSACTION_FAILED', 'Transaction failed');
define('MSG_UNAUTHORIZED_ACCESS', 'Unauthorized access');
define('MSG_EMAIL_EXISTS', 'Email already registered');
define('MSG_INVALID_REQUEST', 'Invalid request');

// Pagination
define('DEFAULT_PAGE_SIZE', 20);
define('MAX_PAGE_SIZE', 100);

// Regex Patterns
define('PATTERN_EMAIL', '/^[^\s@]+@[^\s@]+\.[^\s@]+$/');
define('PATTERN_PHONE', '/^(\+27|0)[0-9]{9}$/');

?>