# ZakhaaPay Backend API

## Setup Instructions

### 1. Database Setup

```bash
mysql -u root -p < database/schema.sql
```

### 2. Configuration

Edit `config/database.php` with your database credentials:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'your_password');
define('DB_NAME', 'zakhaa_pay');
```

### 3. Server Setup

Run a local PHP server:
```bash
php -S localhost:8000
```

## API Endpoints

### Authentication

**Register User**
```
POST /endpoints/auth/register.php
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "27123456789",
  "password": "password123"
}
```

**Login**
```
POST /endpoints/auth/login.php
Content-Type: application/json

{
  "email": "john@example.com",
  "password": "password123"
}
```

### Transactions

**Create Payment**
```
POST /endpoints/transactions/create-payment.php
Authorization: Bearer YOUR_TOKEN
Content-Type: application/json

{
  "amount": 100,
  "recipient_id": 2,
  "description": "Payment description"
}
```

**Get Transactions**
```
GET /endpoints/transactions/get-transactions.php?page=1&pageSize=20
Authorization: Bearer YOUR_TOKEN
```

## Error Handling

All endpoints return JSON responses with the following format:

**Success:**
```json
{
  "status": "success",
  "message": "Operation successful",
  "data": {...}
}
```

**Error:**
```json
{
  "status": "error",
  "message": "Error description",
  "errors": {...}
}
```

## Security Features

- JWT Token-based authentication
- Password hashing with bcrypt
- Input validation and sanitization
- CORS headers enabled
- Database prepared statements for SQL injection prevention
- Transaction support for data consistency

## Default Test User

Email: `zandile.mziwake@gmail.com`
Password: `password123`
Balance: R6,750.85
