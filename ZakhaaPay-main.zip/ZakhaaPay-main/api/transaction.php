<?php
/**
 * Transaction Handler
 */

class TransactionHandler {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function createQRPayment($data, $userId) {
        // Validate
        if (empty($data['amount']) || !is_numeric($data['amount'])) {
            return ['status' => 'error', 'message' => 'Valid amount is required'];
        }
        if (empty($data['recipient_id'])) {
            return ['status' => 'error', 'message' => 'Recipient ID is required'];
        }
        
        $amount = (float)$data['amount'];
        $recipientId = (int)$data['recipient_id'];
        
        if ($amount <= 0 || $amount > MAX_TRANSACTION_AMOUNT) {
            return ['status' => 'error', 'message' => 'Invalid transaction amount'];
        }
        
        // Check sender balance
        $senderBalance = $this->getUserBalance($userId);
        if ($senderBalance === null || $senderBalance['balance'] < $amount) {
            return ['status' => 'error', 'message' => 'Insufficient balance'];
        }
        
        // Start transaction
        $this->conn->begin_transaction();
        
        try {
            $fee = $amount * (TRANSACTION_FEE_PERCENT / 100);
            $totalDebit = $amount + $fee;
            
            // Debit sender
            if (!$this->updateBalance($userId, -$totalDebit)) {
                throw new Exception('Failed to update sender balance');
            }
            
            // Credit recipient
            if (!$this->updateBalance($recipientId, $amount)) {
                throw new Exception('Failed to update recipient balance');
            }
            
            // Record transaction
            $txnId = $this->recordTransaction([
                'sender_id' => $userId,
                'recipient_id' => $recipientId,
                'amount' => $amount,
                'fee' => $fee,
                'type' => 'payment',
                'method' => 'qr',
                'status' => 'success',
                'description' => $data['description'] ?? 'QR Payment'
            ]);
            
            $this->conn->commit();
            
            return [
                'status' => 'success',
                'transaction_id' => $txnId,
                'amount' => $amount,
                'fee' => $fee
            ];
            
        } catch (Exception $e) {
            $this->conn->rollback();
            return ['status' => 'error', 'message' => $e->getMessage()];
        }
    }
    
    public function getUserTransactions($userId, $page = 1, $pageSize = 20) {
        $offset = ($page - 1) * $pageSize;
        
        // Get total count
        $countQuery = "SELECT COUNT(*) as total FROM transactions WHERE sender_id = ? OR recipient_id = ?";
        $stmt = $this->conn->prepare($countQuery);
        $stmt->bind_param("ii", $userId, $userId);
        $stmt->execute();
        $countResult = $stmt->get_result()->fetch_assoc();
        $total = $countResult['total'];
        
        // Get transactions
        $query = "SELECT t.*, 
                         u1.name as sender_name, u1.email as sender_email,
                         u2.name as recipient_name, u2.email as recipient_email
                  FROM transactions t
                  LEFT JOIN users u1 ON t.sender_id = u1.id
                  LEFT JOIN users u2 ON t.recipient_id = u2.id
                  WHERE t.sender_id = ? OR t.recipient_id = ?
                  ORDER BY t.created_at DESC
                  LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("iiii", $userId, $userId, $pageSize, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $transactions = [];
        while ($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
        
        return [
            'status' => 'success',
            'data' => $transactions,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize
        ];
    }
    
    private function recordTransaction($data) {
        $query = "INSERT INTO transactions 
                  (sender_id, recipient_id, amount, fee, type, method, status, description, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())";
        
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            throw new Exception('Database error');
        }
        
        $stmt->bind_param(
            "iiddsss",
            $data['sender_id'] ?? null,
            $data['recipient_id'] ?? null,
            $data['amount'],
            $data['fee'],
            $data['type'],
            $data['method'],
            $data['status'],
            $data['description']
        );
        
        if ($stmt->execute()) {
            return $this->conn->insert_id;
        }
        
        throw new Exception('Failed to record transaction');
    }
    
    private function updateBalance($userId, $amount) {
        $query = "UPDATE users SET balance = balance + ? WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            return false;
        }
        
        $stmt->bind_param("di", $amount, $userId);
        return $stmt->execute();
    }
    
    private function getUserBalance($userId) {
        $query = "SELECT id, balance FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            return null;
        }
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        return $result->fetch_assoc();
    }
}

?>