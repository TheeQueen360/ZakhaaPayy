<?php
/**
 * Middleware Functions
 * Authentication and authorization middleware
 */

function setCorsHeaders() {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    header('Content-Type: application/json; charset=utf-8');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(200);
        exit();
    }
}

function validateMethod($method) {
    $currentMethod = $_SERVER['REQUEST_METHOD'];
    if ($currentMethod !== $method) {
        http_response_code(405);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
        exit();
    }
}

function getJsonBody() {
    $input = file_get_contents('php://input');
    return json_decode($input, true) ?? [];
}

function getQueryParams() {
    return $_GET ?? [];
}

function validateRequiredFields($data, $required) {
    $errors = [];
    foreach ($required as $field) {
        if (!isset($data[$field]) || $data[$field] === '' || $data[$field] === null) {
            $errors[$field] = ucfirst(str_replace('_', ' ', $field)) . ' is required';
        }
    }
    return empty($errors) ? true : $errors;
}

function authenticateUser($conn, $required_role = null) {
    $headers = getallheaders();
    
    if (!isset($headers['Authorization'])) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Authorization header missing']);
        exit();
    }
    
    $authHeader = $headers['Authorization'];
    $token = str_replace('Bearer ', '', $authHeader);
    
    // Verify token
    $user = verifyJWT($token);
    if (!$user) {
        http_response_code(401);
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Invalid or expired token']);
        exit();
    }
    
    // Check role if required
    if ($required_role) {
        $allowed_roles = is_array($required_role) ? $required_role : [$required_role];
        if (!in_array($user['role'], $allowed_roles)) {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(['status' => 'error', 'message' => 'Access denied']);
            exit();
        }
    }
    
    return $user;
}

function generateJWT($user) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload = json_encode([
        'iat' => time(),
        'exp' => time() + 86400,
        'user_id' => $user['id'],
        'email' => $user['email'],
        'role' => $user['role']
    ]);
    
    $header = rtrim(strtr(base64_encode($header), '+/', '-_'), '=');
    $payload = rtrim(strtr(base64_encode($payload), '+/', '-_'), '=');
    
    $signature = rtrim(strtr(
        base64_encode(hash_hmac('sha256', "$header.$payload", JWT_SECRET, true)), 
        '+/', '-_'
    ), '=');
    
    return "$header.$payload.$signature";
}

function verifyJWT($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) {
        return false;
    }
    
    list($header, $payload, $signature) = $parts;
    
    // Verify signature
    $validSignature = hash_hmac('sha256', "$header.$payload", JWT_SECRET, true);
    $validSignature = rtrim(strtr(base64_encode($validSignature), '+/', '-_'), '=');
    
    if ($signature !== $validSignature) {
        return false;
    }
    
    // Decode payload
    $decoded = json_decode(base64_decode(strtr($payload, '-_', '+/')), true);
    
    // Check expiration
    if (!$decoded || $decoded['exp'] < time()) {
        return false;
    }
    
    return $decoded;
}

?>