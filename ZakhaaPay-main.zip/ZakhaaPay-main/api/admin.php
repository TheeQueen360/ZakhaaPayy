<?php
/**
 * Admin Handler for ZakhaaPay
 * Manages admin dashboard and user operations
 */

class AdminHandler {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function getDashboardStats() {
        $stats = [];
        
        $result = $this->conn->query("SELECT SUM(amount) as total FROM transactions WHERE status = 'success'");
        $stats['total_revenue'] = $result->fetch_assoc()['total'] ?? 0;
        
        $result = $this->conn->query("SELECT COUNT(*) as total FROM users");
        $stats['total_users'] = $result->fetch_assoc()['total'] ?? 0;
        
        $result = $this->conn->query("SELECT COUNT(*) as total FROM transactions WHERE status = 'success'");
        $stats['total_transactions'] = $result->fetch_assoc()['total'] ?? 0;
        
        $result = $this->conn->query("SELECT COUNT(*) as total FROM users WHERE role = 'seller'");
        $stats['active_sellers'] = $result->fetch_assoc()['total'] ?? 0;
        
        return $stats;
    }
    
    public function getAllUsers($page = 1, $pageSize = 20) {
        $offset = ($page - 1) * $pageSize;
        
        $countResult = $this->conn->query("SELECT COUNT(*) as total FROM users");
        $total = $countResult->fetch_assoc()['total'];
        
        $query = "SELECT id, name, email, phone, balance, role, status, created_at FROM users ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $pageSize, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        
        return [
            'users' => $users,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize
        ];
    }
    
    public function getAllTransactions($page = 1, $pageSize = 20) {
        $offset = ($page - 1) * $pageSize;
        
        $countResult = $this->conn->query("SELECT COUNT(*) as total FROM transactions");
        $total = $countResult->fetch_assoc()['total'];
        
        $query = "SELECT t.*, u1.name as sender_name, u2.name as recipient_name FROM transactions t LEFT JOIN users u1 ON t.sender_id = u1.id LEFT JOIN users u2 ON t.recipient_id = u2.id ORDER BY t.created_at DESC LIMIT ? OFFSET ?";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $pageSize, $offset);
        $stmt->execute();
        $result = $stmt->get_result();
        
        $transactions = [];
        while ($row = $result->fetch_assoc()) {
            $transactions[] = $row;
        }
        
        return [
            'transactions' => $transactions,
            'total' => $total,
            'page' => $page,
            'pageSize' => $pageSize
        ];
    }
    
    public function updateUserStatus($userId, $status) {
        $query = "UPDATE users SET status = ?, updated_at = NOW() WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        
        if (!$stmt) {
            return ['status' => 'error', 'message' => 'Database error'];
        }
        
        $stmt->bind_param("si", $status, $userId);
        
        if ($stmt->execute()) {
            return ['status' => 'success', 'message' => 'User status updated'];
        }
        
        return ['status' => 'error', 'message' => 'Update failed'];
    }
    
    public function deleteUser($userId) {
        $query = "DELETE FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        
        if (!$stmt) {
            return ['status' => 'error', 'message' => 'Database error'];
        }
        
        $stmt->bind_param("i", $userId);
        
        if ($stmt->execute()) {
            return ['status' => 'success', 'message' => 'User deleted'];
        }
        
        return ['status' => 'error', 'message' => 'Delete failed'];
    }
    
    public function getRevenueStats() {
        $months = [];
        $revenues = [];
        
        for ($i = 5; $i >= 0; $i--) {
            $date = date('Y-m', strtotime("-$i months"));
            $months[] = date('M', strtotime($date));
            
            $query = "SELECT SUM(amount) as total FROM transactions WHERE DATE_FORMAT(created_at, '%Y-%m') = ? AND status = 'success'";
            $stmt = $this->conn->prepare($query);
            $stmt->bind_param("s", $date);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $revenues[] = $result['total'] ?? 0;
        }
        
        return ['months' => $months, 'revenues' => $revenues];
    }
}

?>
