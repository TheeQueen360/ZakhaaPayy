<?php
/**
 * Authentication Handler
 */

class AuthHandler {
    private $conn;
    
    public function __construct($conn) {
        $this->conn = $conn;
    }
    
    public function register($data) {
        // Validate
        $errors = [];
        if (empty($data['name'])) $errors['name'] = 'Name is required';
        if (empty($data['email']) || !preg_match(PATTERN_EMAIL, $data['email'])) {
            $errors['email'] = 'Valid email is required';
        }
        if (empty($data['phone']) || !preg_match(PATTERN_PHONE, $data['phone'])) {
            $errors['phone'] = 'Valid phone number is required';
        }
        if (empty($data['password']) || strlen($data['password']) < 6) {
            $errors['password'] = 'Password must be at least 6 characters';
        }
        
        if (!empty($errors)) {
            return ['status' => 'error', 'errors' => $errors];
        }
        
        // Check if email exists
        $query = "SELECT id FROM users WHERE email = ?";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            return ['status' => 'error', 'message' => 'Database error'];
        }
        
        $stmt->bind_param("s", $data['email']);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            return ['status' => 'error', 'message' => 'Email already registered'];
        }
        
        // Hash password
        $hashedPassword = password_hash($data['password'], PASSWORD_BCRYPT);
        
        // Insert user
        $query = "INSERT INTO users (name, email, phone, password, balance, role, status, created_at) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            return ['status' => 'error', 'message' => 'Database error'];
        }
        
        $balance = 0;
        $role = 'user';
        $status = 'active';
        
        $stmt->bind_param("ssssdss", 
            $data['name'],
            $data['email'],
            $data['phone'],
            $hashedPassword,
            $balance,
            $role,
            $status
        );
        
        if ($stmt->execute()) {
            $userId = $this->conn->insert_id;
            $user = $this->getUserById($userId);
            $token = generateJWT($user);
            
            return [
                'status' => 'success',
                'user' => $user,
                'token' => $token
            ];
        }
        
        return ['status' => 'error', 'message' => 'Registration failed'];
    }
    
    public function login($email, $password) {
        $query = "SELECT * FROM users WHERE email = ? AND status = 'active'";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            return ['status' => 'error', 'message' => 'Database error'];
        }
        
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return ['status' => 'error', 'message' => 'Invalid email or password'];
        }
        
        $user = $result->fetch_assoc();
        
        if (!password_verify($password, $user['password'])) {
            return ['status' => 'error', 'message' => 'Invalid email or password'];
        }
        
        // Update last login
        $updateQuery = "UPDATE users SET last_login = NOW() WHERE id = ?";
        $updateStmt = $this->conn->prepare($updateQuery);
        $updateStmt->bind_param("i", $user['id']);
        $updateStmt->execute();
        
        $token = generateJWT($user);
        unset($user['password']);
        
        return [
            'status' => 'success',
            'user' => $user,
            'token' => $token
        ];
    }
    
    public function getUserById($userId) {
        $query = "SELECT id, name, email, phone, balance, role, status, avatar, created_at FROM users WHERE id = ?";
        $stmt = $this->conn->prepare($query);
        if (!$stmt) {
            return null;
        }
        
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            return null;
        }
        
        return $result->fetch_assoc();
    }
}

?>