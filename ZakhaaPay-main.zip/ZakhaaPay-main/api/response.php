<?php
/**
 * API Response Helper
 * Standardized response format for all API endpoints
 */

class ApiResponse {
    
    /**
     * Send success response
     */
    public static function success($data = null, $message = 'Success', $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        self::sendJson([
            'status' => 'success',
            'message' => $message,
            'data' => $data,
            'timestamp' => time()
        ]);
    }
    
    /**
     * Send error response
     */
    public static function error($message = 'Error', $statusCode = 400, $errors = null) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        self::sendJson([
            'status' => 'error',
            'message' => $message,
            'errors' => $errors,
            'timestamp' => time()
        ]);
    }
    
    /**
     * Send validation error response
     */
    public static function validationError($errors) {
        http_response_code(400);
        header('Content-Type: application/json');
        self::sendJson([
            'status' => 'validation_error',
            'message' => 'Validation failed',
            'errors' => $errors,
            'timestamp' => time()
        ]);
    }
    
    /**
     * Send paginated response
     */
    public static function paginated($data, $total, $page, $pageSize, $message = 'Success') {
        http_response_code(200);
        header('Content-Type: application/json');
        self::sendJson([
            'status' => 'success',
            'message' => $message,
            'data' => $data,
            'pagination' => [
                'page' => (int)$page,
                'pageSize' => (int)$pageSize,
                'total' => (int)$total,
                'totalPages' => ceil($total / $pageSize)
            ],
            'timestamp' => time()
        ]);
    }
    
    /**
     * Send JSON response
     */
    private static function sendJson($data) {
        echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        exit();
    }
}
?>