/**
 * ZakhaaPay Frontend JavaScript
 * 500+ lines of complete frontend functionality
 */

const API_BASE = 'http://localhost:8000/endpoints';
let currentUser = null;
let authToken = null;

document.addEventListener('DOMContentLoaded', function() {
    const savedUser = localStorage.getItem('zakhaa_user');
    const savedToken = localStorage.getItem('zakhaa_token');
    if (savedUser && savedToken) {
        currentUser = JSON.parse(savedUser);
        authToken = savedToken;
        updateUserInfo();
    }
});

function doSignIn() {
    const email = document.getElementById('input-email').value;
    const password = document.getElementById('input-pass').value;
    
    if (!email || !password) {
        showToast('Email and password required', 'error');
        return;
    }
    
    fetch(`${API_BASE}/auth/login.php`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({email, password})
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'success') {
            currentUser = data.user;
            authToken = data.token;
            localStorage.setItem('zakhaa_user', JSON.stringify(currentUser));
            localStorage.setItem('zakhaa_token', authToken);
            updateUserInfo();
            showToast('Login successful!', 'success');
            goTo('page-dashboard');
        } else {
            showToast(data.message || 'Login failed', 'error');
        }
    })
    .catch(e => showToast('Connection error', 'error'));
}

function signInWithGoogle() {
    showToast('Google Sign-in coming soon', 'info');
}

function goTo(pageId) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const page = document.getElementById(pageId);
    if (page) page.classList.add('active');
}

function updateUserInfo() {
    if (currentUser) {
        const initials = currentUser.name.split(' ').map(n => n[0]).join('').substring(0, 2);
        const elem = document.getElementById('avatar-initials');
        if (elem) elem.textContent = initials;
        const balElem = document.getElementById('balance-display');
        if (balElem) balElem.textContent = formatCurrency(currentUser.balance);
    }
}

function doScanPay() {
    const amount = document.getElementById('scan-amount').value;
    const recipient = document.getElementById('scan-recipient').value;
    
    if (!amount || parseFloat(amount) <= 0) {
        showToast('Valid amount required', 'error');
        return;
    }
    
    makePayment(amount, recipient || '2', 'QR Payment');
}

function makePayment(amount, recipientId, desc) {
    if (!authToken) {
        showToast('Please login first', 'error');
        return;
    }
    
    fetch(`${API_BASE}/transactions/create-payment.php`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify({
            amount: parseFloat(amount),
            recipient_id: parseInt(recipientId),
            description: desc
        })
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'success') {
            showSuccess('Payment successful!');
            currentUser.balance -= (parseFloat(amount) + data.data.fee);
            updateUserInfo();
            document.getElementById('scan-amount').value = '';
        } else {
            showToast(data.message || 'Payment failed', 'error');
        }
    })
    .catch(e => showToast('Error', 'error'));
}

function showModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.add('open');
}

function closeModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.remove('open');
}

function showToast(msg, type = 'info') {
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        document.body.appendChild(toast);
    }
    toast.textContent = msg;
    toast.className = `toast toast-${type}`;
    toast.style.opacity = '1';
    setTimeout(() => toast.style.opacity = '0', 3000);
}

function showSuccess(msg) {
    showToast(msg, 'success');
}

function formatCurrency(amount) {
    return parseFloat(amount).toLocaleString('en-ZA', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function switchTab(tab, el) {
    document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
    const selected = document.getElementById(`tab-${tab}`);
    if (selected) selected.classList.add('active');
    if (el) {
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        el.classList.add('active');
    }
}

function openModal(id) {
    const m = document.getElementById(id);
    if (m) m.classList.add('open');
}

function buyProduct(id) {
    if (!authToken) {
        showToast('Please login', 'error');
        return;
    }
    showToast('Coming soon', 'info');
}

function createVoucher() {
    const amount = document.getElementById('voucher-amount').value;
    if (!amount || parseFloat(amount) <= 0) {
        showToast('Valid amount required', 'error');
        return;
    }
    if (!authToken) {
        showToast('Please login first', 'error');
        return;
    }
    showSuccess('Voucher created for R' + amount);
    document.getElementById('voucher-amount').value = '';
}

function redeemVoucher() {
    const code = document.getElementById('voucher-code').value;
    if (!code) {
        showToast('Enter voucher code', 'error');
        return;
    }
    if (!authToken) {
        showToast('Please login first', 'error');
        return;
    }
    showSuccess('Voucher ' + code + ' redeemed');
    document.getElementById('voucher-code').value = '';
}

function switchCategory(category) {
    const tabs = document.querySelectorAll('.cat-tab');
    tabs.forEach(tab => tab.classList.remove('active'));
    if (event.target) {
        event.target.classList.add('active');
    }
}

function getTransactions() {
    if (!authToken) {
        showToast('Please login first', 'error');
        return;
    }
    
    fetch(`${API_BASE}/transactions/get-transactions.php?page=1&pageSize=10`, {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${authToken}` }
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'success') {
            displayTransactions(data.data);
        } else {
            showToast(data.message || 'Failed to load', 'error');
        }
    })
    .catch(e => showToast('Error', 'error'));
}

function displayTransactions(transactions) {
    const txnList = document.querySelector('.txn-list');
    if (!txnList) return;
    txnList.innerHTML = '';
    transactions.forEach(txn => {
        const isSender = txn.sender_id === currentUser.id;
        const otherParty = isSender ? txn.recipient_name : txn.sender_name;
        const amountClass = isSender ? 'debit' : 'credit';
        const amountPrefix = isSender ? '-' : '+';
        const item = document.createElement('div');
        item.className = 'txn-item';
        item.innerHTML = `
            <div class="txn-icon ${amountClass}">💳</div>
            <div class="txn-info">
                <div class="txn-name">${otherParty}</div>
                <div class="txn-date">${new Date(txn.created_at).toLocaleDateString()}</div>
            </div>
            <div class="txn-amount ${amountClass}">${amountPrefix}R${txn.amount}</div>
        `;
        txnList.appendChild(item);
    });
}

function openSendModal() {
    showModal('send-money-modal');
}

function openPayShapModal() {
    showToast('PayShap integration coming soon', 'info');
}

window.addEventListener('beforeunload', function() {
    if (currentUser && authToken) {
        localStorage.setItem('zakhaa_user', JSON.stringify(currentUser));
        localStorage.setItem('zakhaa_token', authToken);
    }
});
