<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

require_once '../../config/database.php';
require_once '../../config/constants.php';
require_once '../../api/response.php';
require_once '../../api/transaction.php';
require_once '../../api/middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit();
}

// Authenticate user
$user = authenticateUser($conn);
$userId = $user['user_id'];

$params = getQueryParams();
$page = isset($params['page']) ? (int)$params['page'] : 1;
$pageSize = isset($params['pageSize']) ? min((int)$params['pageSize'], 100) : 20;

if ($page < 1) $page = 1;
if ($pageSize < 1) $pageSize = 20;

$transaction = new TransactionHandler($conn);
$result = $transaction->getUserTransactions($userId, $page, $pageSize);

http_response_code(200);
echo json_encode($result);
?>