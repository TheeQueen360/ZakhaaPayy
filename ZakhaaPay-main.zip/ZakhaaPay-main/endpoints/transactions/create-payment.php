<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

require_once '../../config/database.php';
require_once '../../config/constants.php';
require_once '../../api/response.php';
require_once '../../api/transaction.php';
require_once '../../api/middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit();
}

// Authenticate user
$user = authenticateUser($conn);
$userId = $user['user_id'];

$data = getJsonBody();

if (empty($data['amount']) || empty($data['recipient_id'])) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Amount and recipient ID are required']);
    exit();
}

$transaction = new TransactionHandler($conn);
$result = $transaction->createQRPayment($data, $userId);

if ($result['status'] === 'success') {
    http_response_code(201);
    echo json_encode($result);
} else {
    http_response_code(400);
    echo json_encode($result);
}
?>