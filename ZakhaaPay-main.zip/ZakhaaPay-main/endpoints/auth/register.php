<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

require_once '../../config/database.php';
require_once '../../config/constants.php';
require_once '../../api/response.php';
require_once '../../api/auth.php';
require_once '../../api/middleware.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit();
}

$data = getJsonBody();

// Validate required fields
$required = ['name', 'email', 'phone', 'password'];
$validation = validateRequiredFields($data, $required);
if ($validation !== true) {
    http_response_code(400);
    echo json_encode(['status' => 'validation_error', 'errors' => $validation]);
    exit();
}

$auth = new AuthHandler($conn);
$result = $auth->register($data);

if ($result['status'] === 'success') {
    http_response_code(201);
    echo json_encode($result);
} else {
    http_response_code(400);
    echo json_encode($result);
}
?>